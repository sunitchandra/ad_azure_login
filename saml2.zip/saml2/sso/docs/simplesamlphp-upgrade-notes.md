SimpeSAMLphp Upgrade Notes
==========================

See the following pages for important information for users upgrading
from older versions of SimpleSAMLphp:

* [Upgrade notes for version 1.19](simplesamlphp-upgrade-notes-1.19)
* [Upgrade notes for version 1.18](simplesamlphp-upgrade-notes-1.18)
* [Upgrade notes for version 1.17](simplesamlphp-upgrade-notes-1.17)
* [Upgrade notes for version 1.16](simplesamlphp-upgrade-notes-1.16)
* [Upgrade notes for version 1.15](simplesamlphp-upgrade-notes-1.15)
* [Upgrade notes for version 1.14](simplesamlphp-upgrade-notes-1.14)
* [Upgrade notes for version 1.13](simplesamlphp-upgrade-notes-1.13)
* [Upgrade notes for version 1.12](simplesamlphp-upgrade-notes-1.12)
* [Upgrade notes for version 1.11](simplesamlphp-upgrade-notes-1.11)
* [Upgrade notes for version 1.10](simplesamlphp-upgrade-notes-1.10)
* [Upgrade notes for version 1.9](simplesamlphp-upgrade-notes-1.9)
* [Upgrade notes for version 1.8](simplesamlphp-upgrade-notes-1.8)
* [Upgrade notes for version 1.7](simplesamlphp-upgrade-notes-1.7)
* [Upgrade notes for version 1.6](simplesamlphp-upgrade-notes-1.6)

A detailed list of changes in each release can be found in the
[Changelog](simplesamlphp-changelog).


