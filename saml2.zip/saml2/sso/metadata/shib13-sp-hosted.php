<?php

/**
 * SAML 1.1 SP configuration for SimpleSAMLphp.
 *
 * Note that SAML 1.1 support has been deprecated and will be removed in SimpleSAMLphp 2.0.
 *
 * See: https://simplesamlphp.org/docs/stable/saml:sp
 */

/*
 * Example of hosted Shibboleth 1.3 SP.
 */
$metadata['__DYNAMIC:1__'] = [
    'host' => '__DEFAULT__',
];
