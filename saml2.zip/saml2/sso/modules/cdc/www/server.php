<?php

\SimpleSAML\Module\cdc\Server::processRequest();
